## functions.py
#pip install boto3

import os

import boto3


# creates an S3 client
def get_S3_client():
  resource = boto3.client("s3")
  return resource


#gets the object from the bucket
def get_file():
  # get the file from the bucket
  s3_client = get_S3_client()

  bucket_name = os.environ.get("BUCKET_NAME")
  file_name = os.environ.get("FILE_NAME")

  #code for testing
  #bucket_name = "No name"
  #file_name = "No name"

  error_code = 200
  error_descript = ""

  if bucket_name is None:
    error_code = 422
    error_descript = "bucket name is not set"

  if file_name is None:
    error_code = 422
    prefix_error = "" if error_code == 200 else " and "
    error_descript += prefix_error + "flie name is not set"

  if error_code == 422:
    return error_code, error_descript

  try:
    file_object = s3_client.get_object(Bucket=bucket_name, Key=file_name)
  except Exception as e:
    error_descript += "Unable to get the file (specified key) "
    error_descript += f"{file_name} from the bucket {bucket_name} with error: {e}"
    return 422, error_descript

  #read the data from the file object and decode it from bytes data to string data
  data_file = file_object["Body"].read()
  return error_code, str(data_file.decode("utf-8"))


#puts the data to the bucket file
def put_file(data_sream):
  s3 = get_S3_client()

  bucket_name = os.environ.get("BUCKET_NAME")
  file_name = os.environ.get("FILE_NAME")

  #code for testing
  #bucket_name = "No name"
  #file_name = "No name"

  error_code = 200
  error_descript = ""

  if bucket_name is None:
    error_code = 422
    error_descript = "bucket name is not set"

  if file_name is None:
    error_code = 422
    prefix_error = "" if error_code == 200 else " and "
    error_descript += prefix_error + "flie name is not set"

  if error_code == 422:
    return error_code, error_descript

  response = s3.put_object(Bucket=bucket_name,
                           Key=file_name,
                           Body=data_sream)

  return error_code, response
