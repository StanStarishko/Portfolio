# lambda_function.py

# handle the request, passing the data to other functions

import json

from functions import get_file, put_file

#from functions import get_file  #, get_statuscode
def lambda_handler(event, context):
  if "body" in event.keys():
    data = event["body"]
    if type(data) is not dict:
      data = json.loads(data)
    #check the need keys
    if "action" in data.keys():
      action = data["action"]
      if action == "get_file":
        statuscode, return_data = get_file()

      elif action == "put_file":
        if "data_stream" in data.keys():
          statuscode, return_data = put_file(data["data_stream"])

        else:
          statuscode = 400
          return_data = "Cloud API error: data_stream is not set"

      else:
        statuscode = 400
        return_data = "Cloud API error: Invalid action"
        
    else:
      statuscode = 422
      return_data = "Cloud API error: Invalid parameters"
      
  else:
    return_data = "Unable to get Body data"
    statuscode = 404

  # now it can return the result in a JSON object with some security settings in the headers
  return {
      'statusCode':
      statuscode,
      'headers': {
          'Content-Type': 'application/json',
          'Access-Control-Allow-Headers': 'Content-Type,X-Api-Key',
          'Access-Control-Allow-Methods': 'POST',
          'Access-Control-Allow-Origin': '*'
      },
      'body':
      json.dumps(return_data)
      if not isinstance(return_data, str) else return_data
  }
