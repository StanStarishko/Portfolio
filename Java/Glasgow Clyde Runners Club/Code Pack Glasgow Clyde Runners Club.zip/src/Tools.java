public interface Tools {
    Boolean checkPassword(); // For Password class
    String getAnsiCode(String colorString); // For TextTools class
    void keyEnter();
} 
